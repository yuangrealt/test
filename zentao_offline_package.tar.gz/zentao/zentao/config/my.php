<?php
$config->installed       = true;
$config->debug           = false;
$config->requestType     = 'GET';
$config->timezone        = 'Asia/Shanghai';
$config->db->driver      = 'mysql';
$config->db->host        = 'zentao-db';
$config->db->port        = '3306';
$config->db->name        = 'zentao';
$config->db->user        = 'my_user';
$config->db->encoding    = 'utf8mb4';
$config->db->password    = 'my_password';
$config->db->prefix      = 'zt_';
$config->webRoot         = getWebRoot();
$config->default->lang   = 'zh-cn';